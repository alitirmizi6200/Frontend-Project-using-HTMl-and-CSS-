function goORDER(){
    location.replace("ORDER.html");
}
function goindex(){
    location.replace("index.html")
}
function goreview(){
  location.replace("review.html")
}


card.addEventListener('click'), () => {
  let text = [];
  text.innerHtml = window.alert("Blog not availble yet, stay tuned!");  
}
function gobrowsecatogories(){
  location.replace("browser categories.html")
}
function goblog(){
  location.replace("blog.html");
}
function ORDER(){
  alert("confirm your order!");
  Location.reload();
}
function open() {
  document.getElementById("info").style.display = "block";
}

function close() {
  document.getElementById().style.display = "none";
}
function gosignup(){
  location.replace("sign up.html")
}
function goinfo(){
  location.replace("info.html")
}
function browse(){
  alert("this section will soon be updated,");
}
function enter(){
  alert("YOUR RESPONSE HAVE BEEN SUBBMITTED! WILL BE NOTIFIED SOON");
  Location.reload();
}